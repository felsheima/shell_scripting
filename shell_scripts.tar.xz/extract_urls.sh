#!/bin/bash

#Create a shell script that uses the DU json file, json.tools, sed OR awk OR cut to parse out just the URL

file="du.json"

while read line; do
    if [[ $count -lt 4 ]]; then
	echo "$line" | awk -F ',' '{print $4}' | awk -F '"' '{print $4}'
	echo "url is $url" 
    fi
    (count++)
done < $file

    
