#!/bin/bash

file="du.json"

while read line; do
    
        url=$(echo "$line" jq ".url" | -d '"' -f 2)
	status=$(echo "$line" | -r jq ".status")
	curl_status=$(curl -L -s -w '%{http_code}\n' "$url" -o /dev/null)
done

if [[ "$status" -ne "$curl_status" ]]; then
    echo "Status is different than $url"
fi
done


