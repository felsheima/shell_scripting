#!/bin/bash

awk -F ',' '{ print $1 }' < more_interesting_data.csv

cat more_interesting_data.csv | awk -F ',' '{ print $1 }'
